# geoffrey-mcp

Multi-account email for any MCP client.

Claude's built-in connectors hold **one** account each — one Gmail, one
Microsoft. This server fronts any number of mailboxes behind a single
connector, because the account is a tool argument rather than a property of the
connection.

## Tools

| Tool | Returns |
|---|---|
| `list_accounts` | Every connected mailbox: id, provider, address, purpose |
| `search_messages` | Summaries only — id, from, subject, date, snippet. Never bodies. |
| `get_message` | Full text of one message by id |

Every tool requires an explicit `account`. Omitting it is a validation error,
not a guess about which mailbox was meant.

`search_messages` deliberately returns no message bodies. Bodies come only from
an explicit `get_message` on one id — otherwise a single search floods the
context window, which degrades the model's reasoning and can exhaust a session
mid-task.

There is no send tool. See `docs/geoffrey-architecture.md`, rule 5.

## Credentials

`~/.geoffrey/accounts.json`, chmod 600, is a secret-free registry containing
only account labels, providers, addresses, and purposes. OAuth client details
and refresh tokens live in the owner's macOS Keychain. Existing plaintext
registries are migrated transactionally on first use, and the legacy backup is
scrubbed only after Keychain storage succeeds.

Access tokens are never written to disk. They are minted per run and cached
only in memory.

## Connect a mailbox

The white-glove package includes Geoffrey's friends-and-family Gmail OAuth app
configuration. A recipient normally does not need to create a Google Cloud app.

```bash
npm install
npm run add-account -- --provider google --id work --purpose "work Gmail"
```

Expect an "unverified app" warning — Advanced → Go to Geoffrey (unsafe). The
script confirms the grant reaches the Gmail API before saving, so a token that
refreshes but cannot read mail fails loudly instead of silently.

If the bundled config is unavailable, pass `--secrets ~/Downloads/client_secret_XXX.json`
as a fallback.

Repeat per mailbox with a different `--id`.

## Use it

Register once, then it is available in every project:

```bash
claude mcp add --scope user geoffrey node /path/to/Geoffrey/geoffrey-mcp/src/index.js
```

## Test

```bash
node smoke-test.mjs
```

Exercises the tool list, a missing account, an unknown account, a real search,
and a real message fetch.

## Status

Geoffrey supports Gmail and Outlook/Microsoft 365. The public package includes
the Microsoft public-client ID in `config/microsoft-oauth.json`, so Outlook
users sign in through Microsoft's browser consent flow.

This is a stdio server so it works locally today. Only the transport is
throwaway — the account registry and provider code move to the hosted Cloudflare
version unchanged.

The desktop app bundles a native Keychain writer so full OAuth JSON travels through stdin without the security tool’s interactive-input length limit. Writes require an exact read-back match. Source checkouts use the helper from `./scripts/build-mac-app.sh`; without a helper they refuse credential writes. Reads and deletes also use the native helper, with Keychain interaction disabled. Reconnect stages a new uniquely keyed item and switches metadata only after read-back, without reading an inaccessible old credential. Best-effort cleanup may leave an inaccessible obsolete item in Keychain; Geoffrey no longer selects it. The optional `scripts/test-native-keychain.py` proof uses only uniquely named dummy items and disables Keychain dialogs; it is not part of default isolated checks.

`scripts/test-native-account-reconnect.py <bundled-helper>` explicitly verifies the real store reconnect/status/removal lifecycle with isolated dummy accounts and mocked provider HTTP responses, with Keychain dialogs disabled and cleanup enforced. It never reads an owner account registry.
